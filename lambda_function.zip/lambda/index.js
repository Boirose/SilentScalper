const AWS = require('aws-sdk');
const s3 = new AWS.S3();
const dynamodb = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event) => {
  try {
    const record = event.Records[0];
    const s3Info = record.s3;

    const bucketName = s3Info.bucket.name;
    const objectKey = decodeURIComponent(s3Info.object.key.replace(/\+/g, " "));

    console.log(`Received file: ${objectKey} from bucket: ${bucketName}`);

    // Here you could read and validate the content of the file, for example
    const params = {
      Bucket: bucketName,
      Key: objectKey,
    };

    const fileObject = await s3.getObject(params).promise();
    const fileContent = fileObject.Body.toString('utf-8');

    console.log("File content:", fileContent);

    // Store metadata or validation results in DynamoDB
    const result = await dynamodb.put({
      TableName: process.env.DYNAMODB_TABLE,
      Item: {
        id: objectKey,
        timestamp: new Date().toISOString(),
        status: "quarantined",
        contentSummary: fileContent.substring(0, 50)
      }
    }).promise();

    console.log("DynamoDB entry created:", result);

    return {
      statusCode: 200,
      body: JSON.stringify('File processed and quarantined successfully.')
    };

  } catch (error) {
    console.error("Error processing file:", error);
    throw new Error("Failed to process and quarantine the file.");
  }
};
